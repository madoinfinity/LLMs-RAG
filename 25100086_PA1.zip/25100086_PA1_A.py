# %% [markdown]
# # Part A: Building a simple RAG-Based Chatbot with LangChain <span style="color:green">**[25 marks]**</span>
# 
# <center>
# <img src="https://images.ctfassets.net/kftzwdyauwt9/5ca4df8a-bd0c-47e0-7efe1b15187a/f891c43eaec1e52760e3cf7c9902a819/gpt-2-1-5b-release.jpg?w=1920&q=90&fm=webp">
# </center>
# 
# In Part A of this assignment, you will explore how to build a chatbot using LangChain, Pinecone and HuggingFace APIs. The goal is to create a chatbot that can answer questions based on the content of a PDF document, in our case the LUMS Student Handbook.
# 
# ---

# %% [markdown]
# ## 0. Instructions
# 
# - Run the entire notebook to ensure everything is working correctly.
# - Modify the chatbot's prompt template(s) to suit your specific use cases (e.g., a different context or more detailed instructions), unless stated otherwise.
# - Do not use GPT or other AI tools to generate code. Refer to documentations instead. It is important you learn these tools yourself for your course projects.

# %% [markdown]
# ## 1. Introduction to LangChain and RAG
# 
# LangChain is a framework and Python library designed to help you build applications powered by large language models (LLMs). It simplifies every stage of the LLM application lifecycle by providing abstractions for integrating various components in order to make applications easy to deploy and scalable. Various components like document loaders, embeddings, vector databases, chains and more, make up your application's cognitive architecture. You can read more about langchain [here](https://python.langchain.com/docs/introduction/).
# 
# RAG, or Retrieval-Augmented Generation, is a technique that enhances the capabilities of LLMs by combining information retrieval with text generation. When a query is posed, a retrieval system searches through a knowledge base, a vast corpus of documents or databases, to find relevant information that can address the query. This additional context is then fed into the language model along with the original query, in order to generate a coherent response. RAG allows us to incorporate up-to-date and specific information that may not have been present in the model's training data, making it particularly valuable for personalized applications.

# %% [markdown]
# ### Installing Dependencies
# 
# Before we dive into the code, ensure that you have the necessary dependencies installed, by either running the cell below, or executing the following command from your preferred terminal.
# 
# ```bash
# pip install langchain langchain-community langchain-huggingface langchain-pinecone pinecone-client python-dotenv streamlit
# ```

# %%
%pip install langchain langchain-community
%pip install langchain-huggingface
%pip install langchain-pinecone pinecone-client
%pip install python-dotenv streamlit

# %% [markdown]
# ### Setting Up API Keys
# 
# You will need to obtain one API key for [HuggingFace](https://huggingface.co/), and one for [Pinecone](https://www.pinecone.io/). Huggingface is where the LLM we will be using for this assignment is hosted, and Pincecone is the vector database we will be using to store our embeddings and create the knowledge base for our RAG chatbot.  You will be required to create an account to use both these serivces.
# 
# - Create a Huggingface account if you do not have one already. Then go to `Profile` > `Edit Profile` > `Access Tokens` > `Create new Token`. Give the token an appropriate name, set the Token type to `Read` and copy the token to your clipboard.
# - Create a Pinecone account if you do not have one already. Click on `API keys` and create a key if one doesn't exist already.
# 
# Once done, run the following cell to save those API keys into a file called `.env` in the same directory as this notebook. You may create this file manually instead if you prefer.

# %%
HUGGINGFACE_API_KEY = "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"  # Replace with your Hugging Face API key
PINECONE_API_KEY = "da1cca19-c5e5-43be-abfc-ec8b7f43ba8c"        # Replace with your Pinecone API key

env_content = f"""
HUGGINGFACE_API_KEY={HUGGINGFACE_API_KEY}
PINECONE_API_KEY={PINECONE_API_KEY}
"""

with open(".env", "w") as file:
    file.write(env_content)

print("Environment variables are saved to .env file.")

# %% [markdown]
# ### Loading the Environment File
# 
# Run the following snippet of code to load the environment file each time you use this notebook

# %%
import dotenv

dotenv.load_dotenv()

# %% [markdown]
# ## 2. Document Loaders Embeddings

# %% [markdown]
# ##### Document Loaders
# LangChain supports various 'document loaders' which can be used to load data from a provided 'document' or source of data. Document loaders are available for various types of files, such as plaintext, webpages, and even more special use-cases like YouTube video transcripts.
# 
# In this assignment, we'll be using `PyMuPDF` to load the contents of a PDF document. This loader treats each page of a given PDF as a separate document and also attaches useful metadata such as the page title, page number and more.
# 
# You can read more about Document Loaders at: https://python.langchain.com/v0.1/docs/modules/data_connection/document_loaders/pdf/
# 
# We will now load the student handbook present in the `handbook` folder. After loading the document, we use the `CharacterTextSplitter` function to split the documents into smaller chunks of text, with `chunk_size` set to 1000 and `chunk_overlap` set to 4.

# %%
from langchain.document_loaders import PyMuPDFLoader
from langchain.text_splitter import CharacterTextSplitter

loader = PyMuPDFLoader('./handbook/Undergraduate Student Handbook 2021-2022.pdf')
documents = loader.load()

text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=4)
docs = text_splitter.split_documents(documents)

# %% [markdown]
# Print a random page or loaded document to see what the extracted data looks like and judge whether the pages were loaded correctly.

# %%
print(documents[171].page_content)

# %% [markdown]
# ## 3. Connecting to Pinecone Database
# 
# Pinecone is a vector database with broad functionality. You have already created a pinecone account in the beginning to obtain an API key. We will now be creating a remote vector store associated with your account which will contain the HuggingFace Embeddings.
# 
# You can read more about integrating pinecone with LangChain at: https://python.langchain.com/v0.2/docs/integrations/vectorstores/pinecone/

# %% [markdown]
# ### Connecting to Pinecone

# %%
import os
from pinecone import Pinecone, ServerlessSpec

pc = Pinecone(api_key=os.environ.get("PINECONE_API_KEY"))

# %% [markdown]
# ### Create Pinecone index if one doesn't exist
# 
# After connecting to Pinecone, create an index if one doesn't already exist. An index is the highest-level organizational unit of vector data in Pinecone. It can accept and store vectors and serve queries related to them.
# 
# You can read more about Pinecone indexes at: https://docs.pinecone.io/guides/indexes/understanding-indexes
# 

# %%
# Defining Index Name
index_name = "handbook-chatbot"

# Checking Index
if index_name not in pc.list_indexes().names():
  # Creating new Index
  pc.create_index(
    name=index_name,
    dimension=768,
    metric="cosine",
    spec=ServerlessSpec(
      cloud="aws",
      region="us-east-1"
    )
  )

# %% [markdown]
# You should now see the 'handbook-chatbot' index present in your pinecone database in the browser. Currently there should be no records present in it.

# %% [markdown]
# ## 4. Creating and Querying the Vector Store
# After creating the Pinecone index, we'll store our document embeddings in it and query the database to retrieve relevant information.

# %% [markdown]
# ### Embeddings
# Embeddings are essentially vectors that are used to represent, in this case text, in a form that can be processed by LLMs. This allows us to map text into a vector space based on its semantic sense. This is very useful for us as it allows us to easily find pieces of text which are most similar to each other by using mathematical operations such as cosine similarity. All of the embeddings collectively make up the knowledge base for our LLM application.
# 
# There are various models which can be used to generate such embeddings. In this assignment, we use `HuggingFaceEmbeddings` to generate embeddings from the text.

# %% [markdown]
# ### Adding Document Embeddings to the Vector Store

# %%
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_pinecone import PineconeVectorStore
from uuid import uuid4

embeddings = HuggingFaceEmbeddings()

index = pc.Index(index_name)

vector_store = PineconeVectorStore(index=index, embedding=embeddings)

uuids = [str(uuid4()) for _ in range(len(documents))]
vector_store.add_documents(documents=documents, ids=uuids)

# %% [markdown]
# There should now be quite a few embeddings in your Pinecone vector store, along with some metedata for each of them, such as the filepath, what page number the embeddings represent and what was the original text that was used to create the embedding.

# %% [markdown]
# ### Querying the Vector Store
# You can directly query the vector store to retrieve the most relevant pages of our document based on a provided search query. `k` is used to indicate how many records should be retrieved for the given request.

# %%
results = vector_store.similarity_search(
    "Grading Policy",
    k=2,
)
for res in results:
    print(f"* {res.page_content} [{res.metadata}]")

# %% [markdown]
# ## 5. Building the Chatbot
# ### Transforming the Vector Store into a Retriever
# To simplify the process of retrieving relevant documents in our chatbot, we'll transform the vector store into a retriever. Retrievers are langchain components that will automatically fetch relevant data from our vector database given the user input. You can read more about retrievers here: https://python.langchain.com/v0.1/docs/modules/data_connection/retrievers/
# 
# Here, we will define our retriever to fetch the two most similar pages on the basis of the cosine similarity score.

# %%
retriever = vector_store.as_retriever(
    search_type="similarity_score_threshold",
    search_kwargs={"k": 2, "score_threshold": 0.5},
)

# %% [markdown]
# ### Setting up the HuggingFace Model
# To provide the LLM, we'll use HuggingFaceHub. HuggingFaceHub is a platform we can connect to and call the model without having to deploy it on our machine. We just define the ID of the model we want to use. In this case, it’s `mistralai/Mixtral-8x7B-Instruct-v0.1`.

# %%
from langchain_huggingface import HuggingFaceEndpoint

# Defining the repo ID and connect to Mixtral model on Huggingface
repo_id = "mistralai/Mixtral-8x7B-Instruct-v0.1"
llm = HuggingFaceEndpoint(
  repo_id=repo_id,
  temperature= 0.8,
  top_k= 50,
  huggingfacehub_api_token=os.getenv('HUGGINGFACE_API_KEY')
)

# %% [markdown]
# ## 6. Prompt Engineering and Template Design
# 
# Prompt engineering is a key part of working with LLMs. Langchain provides a user-friendly interface to construct complex prompts using 'prompt tempaltes'. This is especially useful when implementing advanced prompting techniques such as few-shot examples which you may have already learnt in the course.
# 
# For this section, we'll create a simple prompt template which incorporates the retrieved context and the user's question before sending it to the LLM.

# %%
from langchain import PromptTemplate

# DO NOT CHANGE THE FOLLOWING PROMPT TEMPLATE
template = """
You are a chatbot designed to answer questions from LUMS students. LUMS is a university and you have access to the student handbook.
Use following extract from the handbook to answer the question.
If the context doesn't contain any relevant information to the question, then just say "I don't know".
If you don't know the answer, then just say "I don't know".
Do NOT make something up.

Context: {context}
Question: {question}
Answer: 

"""

prompt = PromptTemplate(
  template=template, 
  input_variables=["context", "question"]
)

# %% [markdown]
# As you can see, we have two input variables defined: `context` and `question`. When a user prompts our chatbot, their question will replace the '{question}' in our prompt template, and the retrived context from our vector store will replace the '{context}' in our prompt template. Thus the fully completed prompt template will now be sent to the LLM for answering.

# %% [markdown]
# ## 7. Chaining It All Together
# 
# Finally, we'll chain the components together using LangChain's LCEL (LangChain Expression Language) to create a fully functional chatbot. This is a proprietary language which simplifies the process of creating complex chains involving prompts and LLMS. LCEL follows the pipe architecture, where the output from the preceding element is used as the input for the next element using the `|` operator. Writing LCEL is as simple as listing which components we want to be excuted as part of our chain and in what order. For example,
# 
# ```bash
# rag_chain = ( 
#             RunnableParallel(context = retriever | format_docs, question = RunnablePassthrough() ) |
#             qa_prompt | 
#             llm 
# )
# ```
# 
# For the following code, a flowchart representation would look like this:
# 
# <center>
# <img src="https://miro.medium.com/v2/resize:fit:1100/format:webp/1*dM-V2AQYihP7-FHkjEmQKA.png">
# </center>
# 
# 
# Learn more about LCEL here: https://python.langchain.com/v0.1/docs/expression_language/

# %% [markdown]
# ### Creating the ChatBot

# %%
from langchain.schema.runnable import RunnablePassthrough
from langchain.schema.output_parser import StrOutputParser

def format_docs(docs):
    return "\n\n".join([d.page_content for d in docs])

rag_chain = (
  {"context": retriever | format_docs,  "question": RunnablePassthrough()} 
  | prompt 
  | llm
  | StrOutputParser() 
)

# %% [markdown]
# Let's break down our LCEL chain step-by-step:
# 
# 1. In the first line, output from our vector store retriever is fed into a function for formatting the document page (so that the chatbot does not need to look at unnecessary metadata) which is then assigned to the `context` input variable we defined earlier. Simultaneously, the input query from the user is assigned to the `question` variable using `RunnablePassthrough`.
# 2. The output of the previous step is fed into the prompt template.
# 3. The prompt template from the previous step is passed to the LLM for inference.
# 4. The output is parsed as a string using `StrOutputParser()`.

# %% [markdown]
# ### Using the RAG-based ChatBot
# 
# We will now test our ChatBot by asking it some highly contextualized questions related to University rules and policy.

# %%
question = "What is the grading policy for the university?"
result = rag_chain.invoke(question)
print(result)

# %%
question = "What are some minors offered at SBASSE?"
result = rag_chain.invoke(question)
print(result)

# %% [markdown]
# ### Testing its limitations
# 
# General questions that are not related to the university would not answered due to the way we structured the prompt template. Try asking such questions below to see.

# %%
question = "What are some gift ideas for Mothers Day?"
result = rag_chain.invoke(question)
print(result)

# %%
question = "What is the fastest land animal?"
result = rag_chain.invoke(question)
print(result)

# %% [markdown]
# ## 8. Dynamically route logic based on input
# 
# One of the key advantages of using LangChain is how easy it makes it to create non-deterministic chains where the output of a previous step defines the next step. Different instances of specialized LLMs can be used to make decisions along the way and perform different sub-tasks.
# 
# You can read more about routing in langchain here: https://python.langchain.com/v0.1/docs/expression_language/how_to/routing/

# %% [markdown]
# ### Creating More Chains <span style="color:red">**[20 marks]**</span>
# 
# In this section, we will be adding another agent which will determine whether the user's query is related to university policy or not, and based on that, the user's query will be passed on to a separate chain with the corresponding prompt templates and RAG access.

# %%
from langchain_core.runnables import RunnableLambda

# 1. Define the classifier chain. This is the chain that takes in the user input to determine if it is related to education/academic policies or not. [5 marks]
classifier_chain = (
    prompt
    | llm  n
    | StrOutputParser()  
)

# 2. Create the General LLM chain. This is the chain that takes in the user input and responds to it. [5 marks]
general_chain = (
    prompt
    | llm  
    | StrOutputParser()  
)

# 3. Implement the routing logic using RunnableLambda in the full_chain and a routing function [10 marks]
def route(info):
    
    info.setdefault("context", "") 
    
    classification = classifier_chain.invoke(info)
   
    
    if "education" in classification.lower() or "academic" in classification.lower():
       
        return classifier_chain.invoke(info)
    else:
       
        return general_chain.invoke(info)


full_chain = RunnableLambda(route)

# %% [markdown]
# ### Testing Our Improved ChatBot <span style="color:red">**[5 marks]**</span>

# %%
question = "What is the my name?"
answer = full_chain.invoke({"question": question})
print(answer)

# %%
question = "What is the biggest school?"
answer = full_chain.invoke({"question": question})
print(answer)

# %% [markdown]
# ## End of Part A


