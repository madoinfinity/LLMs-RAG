import streamlit as st
from dotenv import load_dotenv

load_dotenv()

class ResearchChatbot:
    # TODO: To be implemented
    def __init__(self):
        pass

    # TODO: To be implemented
    def load_papers(self, filepath):
        pass

    # TODO: To be implemented
    def store_papers(self):
        pass

    # TODO: To be implemented
    def generate(self, query):
        return "This is a placeholder response."

bot = ResearchChatbot()
bot.load_papers("")
bot.store_papers()

st.set_page_config(page_title="Research Assistant Chatbot")
with st.sidebar:
    st.title('Research Assistant Chatbot')

# Function for generating LLM response
def generate_response(input):
    result = bot.generate(input)
    return result

# Store LLM generated responses
if "messages" not in st.session_state.keys():
    st.session_state.messages = [{"role": "assistant", "content": "Hello! I am a research assistant chatbot. How can I help you today?"}]

# Display chat messages
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.write(message["content"])

# User-provided prompt
if input := st.chat_input():
    st.session_state.messages.append({"role": "user", "content": input})
    with st.chat_message("user"):
        st.write(input)

# Generate a new response if last message is not from assistant
if st.session_state.messages[-1]["role"] != "assistant":
    with st.chat_message("assistant"):
        with st.spinner("Working on it.."):
            response = generate_response(input) 
            st.write(response) 
    message = {"role": "assistant", "content": response}
    st.session_state.messages.append(message)